import argparse
# import pandas for read the dataframe
import pandas as pd
# import datetime for work on date column
import datetime
# import os for the fullpath
import os
import logging

logging.basicConfig(filename="newfile.log",
                    format='%(asctime)s %(message)s',
                    filemode='w')

global logger
# Creating an object
logger = logging.getLogger()
 
# Setting the threshold of logger to DEBUG
logger.setLevel(logging.DEBUG)

def merge_df(customer_df,product_df,transaction_df):
    try:
        # here we merge transaction_df and customer_df dataframe on the base on customer_id column
        df = pd.merge(transaction_df,customer_df, on='customer_id', how='left')
        df1 = pd.merge(df,product_df,on='product_id', how='left')
        df1 = df1.drop(['product_description'], axis = 1)
        # here we create output file of result
        global logger
        logger.info("file complet result created")
        df2 = df1.to_json(r"output.json",orient = "records")
        return df1
    except Exception as e: 
        print(e)
    
def readFromJson(path):
    try:
        global logger
        logger.info("json file read")
        # here we read the json file using pandas
        df = pd.read_json(path,lines=True)
        # we have json file path in path varible
        df = df.explode('basket')
        df[['product_id', 'price']] = df['basket'].apply(pd.Series)
        df.drop(['basket', 'price'], axis=1, inplace=True)
        # here we get count of dataframe on ['customer_id', 'product_id'] column
        customer_df = df.groupby(['customer_id', 'product_id'], as_index=False).count()
        #here we rename the date_of_purchase columnfor the result
        customer_df.rename(columns={'date_of_purchase': 'purchase_count'}, inplace=True)
        # here this function return customer column
        return customer_df
    except Exception as e: 
        print(e)
def read_transactions(params,start_date,end_date):
    try:
        global logger
        logger.info("path convertion")
        # here we convert abspath to full path
        path = os.path.abspath(params)
        # here we change the formate of date
        start_date = datetime.datetime.strptime(start_date, '%Y-%m-%d')
        end_date = datetime.datetime.strptime(end_date, '%Y-%m-%d')
        delta = datetime.timedelta(days=1)
        # here we create a empty dataframe
        transaction_df = pd.DataFrame(columns=['customer_id', 'product_id', 'purchase_count'])
        folder_path = path
        logger.info("while loop start in range of start_date to end_date ")
        while(start_date <= end_date):
            date = start_date.strftime("%Y-%m-%d")
            file_path = r"{}".format(folder_path) + "\d=" + date
            file = file_path+r"\transactions.json"
            # here we read the json file and get in data frame
            df = readFromJson(file)
            # here we concat json data frame to transaction_df 
            transaction_df = pd.concat([transaction_df,df])
            start_date += delta
        # this function return transaction_df dataframe
        return transaction_df
    except Exception as e: 
        print(e)

def read_products(params):
    try:
        global logger
        logger.info("read products csv")
        # here we read products input csv file
        path = os.path.abspath(params)
        product_df = pd.read_csv(r"{}".format(path))
        return product_df
    except Exception as e: 
        print(e)

def read_customers(params):
    try:
        global logger
        logger.info("read customers csv")
        # here we read products input csv file
        path = os.path.abspath(params)
        customer_df = pd.read_csv(path)
        return customer_df
    except Exception as e: 
        print(e)

def get_params() -> dict:
    parser = argparse.ArgumentParser(description='DataTest')
    parser.add_argument('--customers_location', required=False, default="./input_data/starter/customers.csv")
    parser.add_argument('--products_location', required=False, default="./input_data/starter/products.csv")
    parser.add_argument('--transactions_location', required=False, default="./input_data/starter/transactions/")
    parser.add_argument('--output_location', required=False, default="./output_data/outputs/")
    return vars(parser.parse_args())

def main():
    # this is main function which call each function
    params = get_params()
    customer = read_customers(params=params['customers_location'])
    product = read_products(params=params['products_location'])
    transaction = read_transactions(params['transactions_location'],"2018-12-01","2019-03-01")
    merge_df(customer,product,transaction)

if __name__ == "__main__":
    main()
