from solution_start import *
import pandas as pd

def test_merge():
    assert(len(get_params())) == 4
    params = get_params()
    params = get_params()
    customer = read_customers(params=params['customers_location'])
    product = read_products(params=params['products_location'])
    transaction = read_transactions(params['transactions_location'],"2018-12-01","2019-03-01")
    assert(type(customer) == type(pd.DataFrame()) and len(customer) != 0)
    assert(type(product) == type(pd.DataFrame()) and len(product) != 0)
    assert(type(transaction) == type(pd.DataFrame()) and len(transaction) != 0)
    assert(len(merge_df(customer,product,transaction).columns) == 5)